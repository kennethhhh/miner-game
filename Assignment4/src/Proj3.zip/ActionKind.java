public interface ActionKind {
    public void executeAction(EventScheduler scheduler);
}
